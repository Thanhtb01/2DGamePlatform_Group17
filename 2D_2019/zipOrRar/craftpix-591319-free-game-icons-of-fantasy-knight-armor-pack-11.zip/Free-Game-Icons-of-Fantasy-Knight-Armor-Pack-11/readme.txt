Font that was used for the background of the preview:
http://www.dafont.com/typographica.font
Textures that was used for the background of tge icons and preview:
http://www.onlygfx.com/wp-content/uploads/2016/07/light-brown-leather-1.jpg
http://www.onlygfx.com/wp-content/uploads/2015/11/dirty-old-paper-6.jpg